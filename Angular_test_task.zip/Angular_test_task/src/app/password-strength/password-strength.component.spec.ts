import { Component } from '@angular/core';

@Component({
  selector: 'app-password-strength',
  templateUrl: './password-strength.component.html',
  styleUrls: ['./password-strength.component.css']
})
export class PasswordStrengthComponent {
  password: string = '';
  sectionColors: string[] = ['gray', 'gray', 'gray'];

  onPasswordInput(): void {
    this.updateStrengthIndicator();
  }

  updateStrengthIndicator(): void {
    if (this.password.length === 0) {
      this.sectionColors = ['gray', 'gray', 'gray'];
    } else if (this.password.length < 8) {
      this.sectionColors = ['red', 'red', 'red'];
    } else {
      const hasLetters = /[a-zA-Z]/.test(this.password);
      const hasNumbers = /\d/.test(this.password);
      const hasSymbols = /[!@#$%^&*(),.?":{}|<>]/.test(this.password);

      if (hasLetters && hasNumbers && hasSymbols) {
        this.sectionColors = ['green', 'green', 'green'];
      } else if (
        (hasLetters && hasNumbers) ||
        (hasLetters && hasSymbols) ||
        (hasNumbers && hasSymbols)
      ) {
        this.sectionColors = ['yellow', 'yellow', 'gray'];
      } else {
        this.sectionColors = ['red', 'gray', 'gray'];
      }
    }
  }
}

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-password-strength',
  templateUrl: './password-strength.component.html',
  styleUrls: ['./password-strength.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class PasswordStrengthComponent {
  password: string = '';
  sectionColors: string[] = ['gray', 'gray', 'gray'];
  passwordStrength: string = 'empty';

  onPasswordInput(): void {
    this.updateStrengthIndicator();
  }

  updateStrengthIndicator(): void {
    if (this.password.length === 0) {
      this.sectionColors = ['gray', 'gray', 'gray'];
      this.passwordStrength = 'empty';
    } else if (this.password.length < 8) {
      this.sectionColors = ['red', 'red', 'red'];
      this.passwordStrength = 'short';
    } else {
      const hasLetters = /[a-zA-Z]/.test(this.password);
      const hasNumbers = /\d/.test(this.password);
      const hasSymbols = /[!@#$%^&*(),.?":{}|<>]/.test(this.password);

      if (hasLetters && hasNumbers && hasSymbols) {
        this.sectionColors = ['green', 'green', 'green'];
        this.passwordStrength = 'strong';
      } else if (
        (hasLetters && hasNumbers) ||
        (hasLetters && hasSymbols) ||
        (hasNumbers && hasSymbols)
      ) {
        this.sectionColors = ['yellow', 'yellow', 'gray'];
        this.passwordStrength = 'medium';
      } else {
        this.sectionColors = ['red', 'gray', 'gray'];
        this.passwordStrength = 'weak';
      }
    }
  }
}

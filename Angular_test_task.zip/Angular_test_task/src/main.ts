import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { provideRouter, Routes } from '@angular/router';
import { PasswordStrengthComponent } from './app/password-strength/password-strength.component';

const routes: Routes = [
  { path: '', component: PasswordStrengthComponent }
];

bootstrapApplication(AppComponent, {
  providers: [provideRouter(routes)]
})
  .catch(err => console.error(err));
